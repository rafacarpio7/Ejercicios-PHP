<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tirada Dados</title>
</head>
<body>
    <form action="compruebaTiradas.php" method="post">
        <legend>Tirada de Dados</legend>
        Numero de Tiradas :
        <input type="number" placeholder="numero de tiradas" name="numeroTiradas" >
        <input type="submit" name="btnNumero" value="Enviar Tiradas">
    </form>
</body>
</html>