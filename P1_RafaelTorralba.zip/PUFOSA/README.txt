# Nombre de la base de datos : pufosa (en phpmyadmin)
# Datos de login 

    -Usuario : id de empleado que exista en la base de datos
    -Contraseña : estandar para todos los usuarios "Daw2"

# Estructura de la App

    -Navegabilidad de tablas mediante un navbar
    -Manejo de sesion mediante boton desconectar
    -Insercion, borrado y actualizar datos introducido en cada
     tabla por independiente
    -Control de errores de insercion y modificacion de datos 
     mediante consultas anidadas
    -Control de borrado en cascada de ciertos campos 
    (si un campo tiene asociado algun otro y esta restringido 
    borrarlo en cascada, no permitira borrarlo)

# Diseño

    -Logo propio diseñado con colores calidos
    -Nav bar diseñado para manejarse rapidamente
    -Paleta de colores partiendo de los colores del logo (colores pastel)